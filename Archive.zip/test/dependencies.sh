brew install jq

#sudo apt install jq   # untuk parsing JSON dari curl
jq --version
