const axios = require('axios');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');

dotenv.config({ path: path.join(__dirname, '.env') });

const API_URL = process.env.API_URL;
const EMAIL = process.env.EMAIL || 'admin@example.com';
const PASSWORD = process.env.PASSWORD || 'your-password';
const ACCOUNT_ID = process.env.ACCOUNT_ID;

(async () => {
  try {
    const response = await axios.post(`${API_URL}/login`, {
      username: 'admin', // atau email, tergantung implementasi kamu
      password: PASSWORD
    }, {
      headers: {
        'x-account-id': ACCOUNT_ID
      }
    });

    const token = response.data?.token;
    if (!token) {
      throw new Error('No token received');
    }

    console.log('✅ Login successful!');
    console.log(`🔐 Token: ${token}`);

    // Simpan token ke .env
    const envPath = path.join(__dirname, '.env');
    const env = fs.readFileSync(envPath, 'utf-8').split('\n');
    const filtered = env.filter(line => !line.startsWith('TOKEN='));
    filtered.push(`TOKEN=${token}`);
    fs.writeFileSync(envPath, filtered.join('\n'), 'utf-8');
    console.log('💾 TOKEN saved to .env');

  } catch (err) {
    console.error('❌ Login failed:', err.response?.data || err.message);
  }
})();