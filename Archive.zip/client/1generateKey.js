const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const { ethers } = require('ethers');

const envPath = path.join(__dirname, '.env');
dotenv.config({ path: envPath });

// Load existing .env as object
const lines = fs.readFileSync(envPath, 'utf-8').split('\n');
const env = Object.fromEntries(lines.filter(Boolean).map(line => {
  const [key, ...rest] = line.split('=');
  return [key, rest.join('=')];
}));

if (env.PRIVATE_KEY && env.ACCOUNT_ID) {
  console.log('✅ PRIVATE_KEY and ACCOUNT_ID already exist in .env');
  console.log(`Address: ${new ethers.Wallet(env.PRIVATE_KEY).address}`);
  process.exit(0);
}

if (env.PRIVATE_KEY) {
  console.log('🔐 PRIVATE_KEY already exists. Skipping generation.');
  process.exit(0);
}

const wallet = ethers.Wallet.createRandom();
console.log('✅ New wallet generated.');
console.log(`Address: ${wallet.address}`);

// Update or append PRIVATE_KEY line
const updatedLines = lines.filter(line => !line.startsWith('PRIVATE_KEY='));
updatedLines.push(`PRIVATE_KEY=${wallet.privateKey}`);
fs.writeFileSync(envPath, updatedLines.join('\n'), 'utf-8');