const path = require('path'); // ⬅️ Tambahkan ini
require('dotenv').config({ path: path.resolve(__dirname, '.env') });

const express = require('express');

if (!process.env.JWT_SECRET) {
  throw new Error('❌ Missing JWT_SECRET in .env');
}
const MODE=process.env.EVENT_PROCESS_MODE;

console.log(`📤 Sending event via: ${MODE}`);

module.exports = function () {
  const app = express();

  // Middleware global
  app.use(express.json());

  // Route imports
  const eventRoutes = require('./routes/events.route');
  const accountRoutes = require('./routes/accounts.route');
  const userRoutes = require('./routes/users.route');
  const schemaRoutes = require('./routes/schemas.route');
  const authRoutes = require('./routes/auth.route');
  const stateRoutes = require('./routes/states.route');
  const authMiddleware = require('./middlewares/auth');
  const accountResolver = require('./middlewares/accountResolver');

  
  // Routes
  app.use('/events', [authMiddleware, accountResolver]);
  app.use('/schemas', [authMiddleware, accountResolver]);
  app.use('/users', authMiddleware);
  app.use('/accounts', authMiddleware, accountRoutes);
  app.use('/login', authRoutes);
  app.use('/states', authMiddleware, stateRoutes);

  // Default route
  app.get('/', (req, res) => res.send('OperaDB API is running.'));

  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`API server running on port ${PORT}`);
  });
};