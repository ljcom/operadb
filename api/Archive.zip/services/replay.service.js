const axios = require('axios');
const reducers = {
  product: require('../reducers/product'),
  // Tambahkan entitas lain di sini
};

const GATEWAY = process.env.MONGO_GATEWAY_URL;
const SECRET = process.env.GATEWAY_SECRET;

exports.handleEventReplay = async (event) => {
  const { type, data, account, _id } = event;
  const [entityType] = type.split('.');

  const reducer = reducers[entityType];
  if (!reducer || !reducer.replay) return;

  const refId = data.id || data.refId || data.product_id;

  // 🔁 Ambil semua event terkait (sebelumnya pakai Event.find)
  const relatedEventsRes = await axios.post(`${GATEWAY}/find`, {
    collection: 'events',
    query: {
      'data.product_id': refId,
      type: { $regex: `^${entityType}\\.` },
      account
    },
    sort: { timestamp: 1 }
  }, {
    headers: {
      Authorization: `Bearer ${SECRET}`
    }
  });

  const relatedEvents = relatedEventsRes.data;

  // 🔁 Hitung ulang state
  const state = reducer.replay(relatedEvents);

  // 🔁 Simpan ke /state (dulu pakai findOneAndUpdate)
  await axios.post(`${GATEWAY}/update`, {
    collection: 'states',
    filter: {
      entityType,
      refId,
      account
    },
    updateDoc: {
      $set: {
        state,
        lastEventId: _id,
        updatedAt: new Date()
      }
    },
    options: {
      upsert: true
    }
  }, {
    headers: {
      Authorization: `Bearer ${SECRET}`
    }
  });
};