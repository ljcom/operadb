const { insertToGateway } = require('../utils/gatewayWriter');
const { findFromGateway } = require('../utils/gatewayQuery');

exports.createAccount = async (req, res) => {
  try {
    const randomName = 'Account_' + Math.random().toString(36).substring(2, 8);
    const account = {
      name: randomName,
      status: 'active',
      createdAt: new Date()
    };

    const response = await insertToGateway('accounts', account);

    res.status(201).json({
      message: 'Account created',
      account: {
        _id: response.data.insertedId,
        name: account.name,
        status: account.status
      }
    });

  } catch (err) {
    // ⬇️ Hanya di sini error ditangani
    console.error('Create Account Error:', err.message);
    res.status(500).json({ error: 'Failed to create account' });
  }
};

exports.listAccounts = async (req, res) => {
  try {
    const data = await findFromGateway('accounts');
    res.json(data);
  } catch (err) {
    console.error('Error accessing mongo-gateway:', err.message);
    res.status(500).json({ error: 'Internal server error' });
  }
};