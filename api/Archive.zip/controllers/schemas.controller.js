const { insertToGateway } = require('../utils/gatewayWriter');

exports.createSchema = async (req, res) => {
  try {
    const { accountId, schemaId, description, fields, reducerCode, version } = req.body;

    if (!accountId || !schemaId || !reducerCode) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const schema = {
      account: accountId,
      schemaId,
      description,
      fields,
      reducerCode,
      version,
      createdAt: new Date()
    };

    const response = await insertToGateway('schemas', schema);

    res.status(201).json({ message: 'Schema created', schema });
  } catch (err) {
    console.error('Failed to create schema:', err.message);
    res.status(500).json({ error: 'Failed to create schema' });
  }
};