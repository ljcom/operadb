const { insertToGateway } = require('../utils/gatewayWriter');

exports.createUser = async (req, res) => {
  try {
    const { accountId, username, email, role } = req.body;

    if (!accountId || !username) {
      return res.status(400).json({ error: 'Missing accountId or username' });
    }

    const user = {
      account: accountId,
      username,
      email,
      role,
      createdAt: new Date()
    };

    const response = await insertToGateway('users', user);

    res.status(201).json({ message: 'User created', user });
  } catch (err) {
    console.error('Failed to create user:', err.message);
    res.status(500).json({ error: 'Failed to create user' });
  }
};