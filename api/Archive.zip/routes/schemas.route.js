const express = require('express');
const router = express.Router();
const schemaController = require('../controllers/schemas.controller');

const GATEWAY = process.env.MONGO_GATEWAY_URL;
const SECRET = process.env.GATEWAY_SECRET;

router.post('/', schemaController.createSchema);

// GET /schemas → semua schema
router.get('/', async (req, res) => {
  try {
    const result = await axios.post(`${GATEWAY}/find`, {
      collection: 'schemas',
      query: {}
    }, {
      headers: { Authorization: `Bearer ${SECRET}` }
    });

    const schemas = result.data;

    // Optional: manual populate 'account'
    for (const s of schemas) {
      if (s.account) {
        const accRes = await axios.post(`${GATEWAY}/find`, {
          collection: 'accounts',
          query: { _id: s.account }
        }, {
          headers: { Authorization: `Bearer ${SECRET}` }
        });
        s.account = accRes.data[0] || null;
      }
    }

    res.json(schemas);
  } catch (err) {
    console.error('Failed to fetch schemas:', err.message);
    res.status(500).json({ error: 'Failed to fetch schemas' });
  }
});

// GET /schemas/:id
router.get('/:id', async (req, res) => {
  try {
    const result = await axios.post(`${GATEWAY}/find`, {
      collection: 'schemas',
      query: { _id: req.params.id }
    }, {
      headers: { Authorization: `Bearer ${SECRET}` }
    });

    const schema = result.data[0];
    if (!schema) return res.status(404).json({ error: 'Schema not found' });

    if (schema.account) {
      const accRes = await axios.post(`${GATEWAY}/find`, {
        collection: 'accounts',
        query: { _id: schema.account }
      }, {
        headers: { Authorization: `Bearer ${SECRET}` }
      });
      schema.account = accRes.data[0] || null;
    }

    res.json(schema);
  } catch (err) {
    console.error('Failed to fetch schema by ID:', err.message);
    res.status(500).json({ error: 'Failed to fetch schema' });
  }
});

// GET /schemas/byname/:schemaId
router.get('/byname/:schemaId', async (req, res) => {
  try {
    const result = await axios.post(`${GATEWAY}/find`, {
      collection: 'schemas',
      query: { schemaId: req.params.schemaId }
    }, {
      headers: { Authorization: `Bearer ${SECRET}` }
    });

    const schema = result.data[0];
    if (!schema) return res.status(404).json({ error: 'Schema not found' });

    if (schema.account) {
      const accRes = await axios.post(`${GATEWAY}/find`, {
        collection: 'accounts',
        query: { _id: schema.account }
      }, {
        headers: { Authorization: `Bearer ${SECRET}` }
      });
      schema.account = accRes.data[0] || null;
    }

    res.json(schema);
  } catch (err) {
    console.error('Failed to fetch schema by schemaId:', err.message);
    res.status(500).json({ error: 'Failed to fetch schema by schemaId' });
  }
});

module.exports = router;