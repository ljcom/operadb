const express = require('express');
const router = express.Router();
const userController = require('../controllers/users.controller');

const GATEWAY = process.env.MONGO_GATEWAY_URL;
const SECRET = process.env.GATEWAY_SECRET;

router.post('/', userController.createUser);


// GET all users
router.get('/', async (req, res) => {
  try {
    const response = await axios.post(`${GATEWAY}/find`, {
      collection: 'users',
      query: {}
    }, {
      headers: { Authorization: `Bearer ${SECRET}` }
    });

    const users = response.data;

    // Optional: populate account manually (looping)
    for (const user of users) {
      if (user.account) {
        const accRes = await axios.post(`${GATEWAY}/find`, {
          collection: 'accounts',
          query: { _id: user.account }
        }, {
          headers: { Authorization: `Bearer ${SECRET}` }
        });
        user.account = accRes.data[0] || null;
      }
    }

    res.json(users);
  } catch (err) {
    console.error('Failed to fetch users:', err.message);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// GET user by ID
router.get('/:id', async (req, res) => {
  try {
    const response = await axios.post(`${GATEWAY}/find`, {
      collection: 'users',
      query: { _id: req.params.id }
    }, {
      headers: { Authorization: `Bearer ${SECRET}` }
    });

    const user = response.data[0];
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (user.account) {
      const accRes = await axios.post(`${GATEWAY}/find`, {
        collection: 'accounts',
        query: { _id: user.account }
      }, {
        headers: { Authorization: `Bearer ${SECRET}` }
      });
      user.account = accRes.data[0] || null;
    }

    res.json(user);
  } catch (err) {
    console.error('Failed to fetch user by ID:', err.message);
    res.status(500).json({ error: 'Failed to fetch user by ID' });
  }
});

// GET /users/byname/:username
router.get('/byname/:username', async (req, res) => {
  try {
    const response = await axios.post(`${GATEWAY}/find`, {
      collection: 'users',
      query: { username: req.params.username }
    }, {
      headers: { Authorization: `Bearer ${SECRET}` }
    });

    const user = response.data[0];
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (user.account) {
      const accRes = await axios.post(`${GATEWAY}/find`, {
        collection: 'accounts',
        query: { _id: user.account }
      }, {
        headers: { Authorization: `Bearer ${SECRET}` }
      });
      user.account = accRes.data[0] || null;
    }

    res.json(user);
  } catch (err) {
    console.error('Failed to fetch user by username:', err.message);
    res.status(500).json({ error: 'Failed to fetch user by username' });
  }
});

module.exports = router;