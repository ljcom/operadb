const express = require('express');
const router = express.Router();
const axios = require('axios');
const accountController = require('../controllers/accounts.controller');

const GATEWAY = process.env.MONGO_GATEWAY_URL;
const SECRET = process.env.GATEWAY_SECRET;

router.post('/', accountController.createAccount);

router.get('/', async (req, res) => {
  try {
    const result = await axios.post(`${GATEWAY}/find`, {
      collection: 'accounts',
      query: {}
    }, {
      headers: {
        Authorization: `Bearer ${SECRET}`
      }
    });
    res.json(result.data);
  } catch (err) {
    console.error('Failed to fetch accounts:', err.message);
    res.status(500).json({ error: 'Failed to fetch accounts' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const result = await axios.post(`${GATEWAY}/find`, {
      collection: 'accounts',
      query: { _id: req.params.id }
    }, {
      headers: {
        Authorization: `Bearer ${SECRET}`
      }
    });

    const account = result.data[0];
    if (!account) return res.status(404).json({ error: 'Account not found' });
    res.json(account);
  } catch (err) {
    console.error('Failed to fetch account:', err.message);
    res.status(500).json({ error: 'Failed to fetch account' });
  }
});

router.get('/byname/:name', async (req, res) => {
  try {
    const result = await axios.post(`${GATEWAY}/find`, {
      collection: 'accounts',
      query: { name: req.params.name }
    }, {
      headers: {
        Authorization: `Bearer ${SECRET}`
      }
    });

    const account = result.data[0];
    if (!account) return res.status(404).json({ error: 'Account not found' });
    res.json(account);
  } catch (err) {
    console.error('Failed to fetch account by name:', err.message);
    res.status(500).json({ error: 'Failed to fetch account by name' });
  }
});

module.exports = router;