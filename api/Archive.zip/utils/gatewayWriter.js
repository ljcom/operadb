const axios = require('axios');

const GATEWAY = process.env.MONGO_GATEWAY_URL;
const SECRET = process.env.GATEWAY_SECRET;

exports.insertToGateway = async (collection, doc) => {
  return axios.post(`${GATEWAY}/insert`, {
    collection,
    doc
  }, {
    headers: {
      Authorization: `Bearer ${SECRET}`
    }
  });
};